# Start NovaShell 11 without opening a console window when launched by pythonw.
from NovaShell11 import main

if __name__ == "__main__":
    raise SystemExit(main())
