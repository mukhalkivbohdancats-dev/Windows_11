@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 NovaShell11.py %*
) else (
    python NovaShell11.py %*
)
if errorlevel 1 (
    echo.
    echo NovaShell did not start. Check that Python 3.10+ with Tkinter is installed.
    pause
)
